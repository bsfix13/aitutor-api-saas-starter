import Link from 'next/link';
import SettingsPage from '../page';

export default function TeamSettings() {
    return (

                    <SettingsPage />

    );
}
